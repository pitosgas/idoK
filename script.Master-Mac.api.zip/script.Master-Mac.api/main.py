# -*- coding: utf-8 -*-
import os
import sys
import six
import shutil
import xbmc
import xbmcvfs
import xbmcgui
import xbmcaddon
from six.moves import urllib_request, urllib_parse, urllib_error, http_cookiejar, html_parser
from xml.etree import ElementTree
try:
    from xbmcvfs import translatePath
except ImportError:
    from xbmc import translatePath
url = 'https://pastebin.com/raw/kBtNb8ku'
AddonID = xbmcaddon.Addon().getAddonInfo('id')
addon = xbmcaddon.Addon(id=AddonID)
addonname = addon.getAddonInfo('name')
icon = addon.getAddonInfo('icon')
addondir = translatePath(os.path.join('special://home/addons/'))
dst = translatePath(os.path.join('special://home/addons/plugin.video.Master-Mac/resources/settings.xml'))
dialog = xbmcgui.Dialog()

if dialog:
	if not os.path.exists(dst):
		xbmcgui.Dialog().notification(addonname, 'Processo cancelado!', icon, 5000, False)
		dialog = xbmcgui.Dialog()
		dialog.ok("Configurações do Master Mac", "Configurações não podem ser atualizadas com sucesso.\nO Kodi não encontrou o addon [COLOR maroon]MASTER[/COLOR] [COLOR gold]MAC[/COLOR] sendo assim, não foram feitas qualquer alteração.")
	else:

		line=urllib_request.urlopen(url).read()
		with open(dst, 'w+') if six.PY2 else open(dst,'w+', encoding='utf-8') as f:
			content = f.read()
			f.write(line.decode('utf-8').replace('\r', '') + content)
			f.close()


		dialog = xbmcgui.Dialog()
		dialog.ok("Configurações do Master Mac", "Configurações atualizadas com sucesso.\nO Kodi irá fechar para que as alterações tenham efeito.")
		os._exit(1)
else:
	dialog = xbmcgui.Dialog()
	dialog.ok("Configurações do Master Mac", "\nConfigurações canceladas pelo utilizador.")	